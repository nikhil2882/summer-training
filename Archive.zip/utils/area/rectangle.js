function calculateAreaRectangle(width, height) {
  return width * height;
}

module.exports = calculateAreaRectangle;
